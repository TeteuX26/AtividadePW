/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exercicio32;

import javax.swing.JOptionPane;

/**
 *
 * @author anaca
 */
public class Exercicio32 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
           int i = 1;
        String numeros = "";
        while (i <= 20) {
            numeros += i + " ";
            i++;
        }
        JOptionPane.showMessageDialog(null, numeros);

    }
    
}
