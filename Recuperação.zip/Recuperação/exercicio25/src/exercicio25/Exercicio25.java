/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exercicio25;
import java.util.Scanner;
/**
 *
 * @author anaca
 */
public class Exercicio25 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);
    
    int maior = Integer.MIN_VALUE;
    
    System.out.println("Digite 10 numeros");
    
    for (int i = 1; i <= 10; i++) {
        System.out.println("Numero " + i + ":");
        int n = scanner.nextInt();
       
        if (n > maior) {
            maior = n;
        }
    }  
     System.out.println("O numero maior eh:" + maior);
        
          scanner.close();
  }
    
}
