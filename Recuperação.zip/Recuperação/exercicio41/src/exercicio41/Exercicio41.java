/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exercicio41;

/**
 *
 * @author anaca
 */
public class Exercicio41 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       int i = 1;
        do {
            System.out.println(i);
            i++;
        } while (i <= 10);

    }
    
}
