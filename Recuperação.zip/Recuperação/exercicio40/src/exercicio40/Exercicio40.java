/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exercicio40;

import javax.swing.JOptionPane;

/**
 *
 * @author anaca
 */
public class Exercicio40 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
           int opcao;
        double n1, n2, resultado;

        do {
            opcao = Integer.parseInt(JOptionPane.showInputDialog(
                "CALCULADORA\n" +
                "1 - Adição\n" +
                "2 - Subtração\n" +
                "3 - Multiplicação\n" +
                "4 - Divisão\n" +
                "0 - Sair\n" +
                "Escolha uma opção:"
            ));

            if (opcao >= 1 && opcao <= 4) {
                n1 = Double.parseDouble(JOptionPane.showInputDialog("Digite o 1º número:"));
                n2 = Double.parseDouble(JOptionPane.showInputDialog("Digite o 2º número:"));

                switch (opcao) {
                    case 1:
                        resultado = n1 + n2;
                        JOptionPane.showMessageDialog(null, "Resultado: " + resultado);
                        break;
                    case 2:
                        resultado = n1 - n2;
                        JOptionPane.showMessageDialog(null, "Resultado: " + resultado);
                        break;
                    case 3:
                        resultado = n1 * n2;
                        JOptionPane.showMessageDialog(null, "Resultado: " + resultado);
                        break;
                    case 4:
                        if (n2 != 0) {
                            resultado = n1 / n2;
                            JOptionPane.showMessageDialog(null, "Resultado: " + resultado);
                        } else {
                            JOptionPane.showMessageDialog(null, "Erro: Divisão por zero!");
                        }
                        break;
                }
            } else if (opcao != 0) {
                JOptionPane.showMessageDialog(null, "Opção inválida!");
            }

        } while (opcao != 0);

        JOptionPane.showMessageDialog(null, "Calculadora encerrada.");
    }

    }
    

