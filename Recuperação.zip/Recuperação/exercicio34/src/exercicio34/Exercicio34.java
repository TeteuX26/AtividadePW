/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exercicio34;

import javax.swing.JOptionPane;

/**
 *
 * @author anaca
 */
public class Exercicio34 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      int valor, cont = 0;
        int soma = 0;
        do {
            valor = Integer.parseInt(JOptionPane.showInputDialog("Digite um valor positivo (negativo para sair):"));
            if (valor >= 0) {
                soma += valor;
                cont++;
            }
        } while (valor >= 0);
        JOptionPane.showMessageDialog(null, "Média: " + (cont > 0 ? (soma / cont) : 0));
    }
    
}
