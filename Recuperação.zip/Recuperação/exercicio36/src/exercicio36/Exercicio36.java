/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exercicio36;

import javax.swing.JOptionPane;

/**
 *
 * @author anaca
 */
public class Exercicio36 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int opcao;
        do {
            opcao = Integer.parseInt(JOptionPane.showInputDialog("Menu:\n1 - Opção 1\n2 - Opção 2\n0 - Sair"));
            JOptionPane.showMessageDialog(null, "Você escolheu: " + opcao);
        } while (opcao != 0);
    }
    
}
