/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exercicio22;
import java.util.Scanner;
/**
 *
 * @author anaca
 */
public class Exercicio22 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Scanner scanner = new Scanner(System.in);
        int soma = 0;
        System.out.println("Digite 5 numeros:");
       
       for (int i = 1; i <= 5; i++) {
           System.out.println("Numero " + i + ":");
           int num = scanner.nextInt();
           soma += num;
       }
       System.out.println("A soma dos 5 numeros eh: 1" + soma);
        
       scanner.close();
    } 
}

