/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exercicio27;
import java.util.Scanner;
/**
 *
 * @author anaca
 */
public class Exercicio27 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);
    
    String[] nomes = new String[5];
    double[] notas = new double[5];
    
    for (int i = 0; i < 5; i++) {
        System.out.print("Digite o nome do aluno " + (i + 1) + ":");
        nomes[i] = scanner.nextLine();
        
        System.out.print("Nota 1 de " + nomes[i] + ":");
        double nota1 = scanner.nextDouble();
        
        System.out.print("Nota 2 de " + nomes[i] + ":");
        double nota2 = scanner.nextDouble();
        
        scanner.nextLine();
        notas[i] = (nota1 + nota2) / 2;
    }
    System.out.println("Medias dos alunos:");
    for (int i = 0; i < 5; i++) {
        System.out.println(nomes[i] + " - Media: " + notas[i]);
    }
    scanner.close();
    
    }
    
}
