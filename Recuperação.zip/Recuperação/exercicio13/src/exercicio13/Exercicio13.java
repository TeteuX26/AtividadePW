/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exercicio13;
import javax.swing.JOptionPane;
/**
 *
 * @author anaca
 */
public class Exercicio13 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       String letra = JOptionPane.showInputDialog("Digite apenas uma letra:");
    
       switch (letra.toLowerCase()) {
           case "a":
           case "e":
           case "i":
           case "o":
           case "u":
         
               JOptionPane.showMessageDialog(null,"A letra inserida é: Vogal" );
               break;
               
           default:
               JOptionPane.showMessageDialog(null,"A letra inserida é: Consoante");
               break;
       }
    }
    
}
