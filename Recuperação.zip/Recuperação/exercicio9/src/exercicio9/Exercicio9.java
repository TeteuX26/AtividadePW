/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exercicio9;
import java.util.Scanner;
/**
 *
 * @author anaca
 */
public class Exercicio9 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Scanner scanner = new Scanner (System.in);
        int [][] matriz = new int [5][5];
        int maior = Integer.MIN_VALUE;
        int colunaMaior = 0;
        int linhaMaior = 0; 
        
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                System.out.println("Digite o numero da posicao[" + i + "][" + j + "]:");
                matriz[i][j] = scanner.nextInt();
                
                if (matriz[i][j] > maior) {
                    maior = matriz[i][j];
                    linhaMaior = i;
                    colunaMaior = j;
                }
            }
       }
           System.out.println("O maior valor da matriz eh:" + maior);
           System.out.println("Ele esta na posicao[" + linhaMaior +"][" + colunaMaior +"]:");
           
           scanner.close();
    }
}
