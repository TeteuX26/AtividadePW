/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exercicio39;

import javax.swing.JOptionPane;

/**
 *
 * @author anaca
 */
public class Exercicio39 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String login;
        String senha;

        do {
            login = JOptionPane.showInputDialog("Login:");
            senha = JOptionPane.showInputDialog("Senha:");
        } while (!login.equals("admin") || !senha.equals("1234"));

        JOptionPane.showMessageDialog(null, "Acesso permitido!");
    }
}