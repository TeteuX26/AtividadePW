/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exercicio18;
import javax.swing.JOptionPane;
/**
 *
 * @author anaca
 */
public class Exercicio18 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    int opcao = Integer.parseInt(JOptionPane.showInputDialog("Escolha uma das opções de conversão:\n"
              + "1 - Quilometros para Metros\n"
              + "2 - Metros para Centimetros\n"
              + "3 - Centimetros para Milimetros\n"
              + "4 - Metros para Quilometros\n"
              + "5 - Centimetros para Metros\n"
              + "6 - Milimetros para Centimetros"));
     
      double valor = Double.parseDouble(JOptionPane.showInputDialog("Digite o valor para ser convertido:"));
      double resultado = 0;
      String mensagem = "";
      
      switch (opcao) {
          case 1:
              resultado = valor * 1000;
              mensagem = valor + "km = " + resultado + "m";
              break;
              
          case 2:
              resultado = valor * 100;
              mensagem = valor + "m = " + resultado + "cm";
              break;
              
          case 3:
              resultado = valor * 10;
              mensagem = valor + "cm = " + resultado + "mm";
              break;
          
          case 4:
              resultado = valor / 1000;
              mensagem = valor + "m = " + resultado + "km";
              break;
              
          case 5:
              resultado = valor / 100;
              mensagem = valor + "cm = " + resultado + "m";
              break;
              
          case 6:
              resultado = valor / 10;
              mensagem = valor + "mm = " + resultado + "cm";
              break;
              
              default:
              mensagem = "Opção inválida";
    }
      JOptionPane.showMessageDialog(null, mensagem);
  } 
}
