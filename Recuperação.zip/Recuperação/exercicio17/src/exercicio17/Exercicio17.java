/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exercicio17;
import javax.swing.JOptionPane;
/**
 *
 * @author anaca
 */
public class Exercicio17 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int num1 = Integer.parseInt(JOptionPane.showInputDialog("Digite um número:"));
        int num2 = Integer.parseInt(JOptionPane.showInputDialog("Digite outro número"));
        String operador = JOptionPane.showInputDialog("Digite o operador: (+,-,*,/)");
        
        switch (operador) {
            case "+":
                JOptionPane.showMessageDialog(null,"O resultado da operação é:" + (num1 + num2));
                break;
                
            case "-":
                JOptionPane.showMessageDialog(null, "O resultado da operação é:" + (num1 - num2));
                break;
                
            case "*":
                JOptionPane.showMessageDialog(null, "O resultado da operação é:" + (num1 * num2));
                break;
                
            case "/":
                JOptionPane.showMessageDialog(null, "O resultado da operação é:" + (num1 / num2));
                break;
                
            default:
                JOptionPane.showMessageDialog(null,"Operação inválida");
                break;   
        }
    }
    
}
