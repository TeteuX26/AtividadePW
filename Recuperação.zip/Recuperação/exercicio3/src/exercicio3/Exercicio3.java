/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exercicio3;
import java.util.Scanner;
/**
 *
 * @author anaca
 */
public class Exercicio3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
     Scanner scanner = new Scanner (System.in);
      int [] vetor = new int [10];
      int numero = 2;
   for (int i = 0; i < vetor.length; i++) {
   vetor[i] = numero;
   numero += 2;
   }
   System.out.println("Valores de 2 a 20:");
    for (int i = 0; i < vetor.length; i++) {
        System.out.println(vetor[i]);
     }
     scanner.close();
     
    }
    
}
