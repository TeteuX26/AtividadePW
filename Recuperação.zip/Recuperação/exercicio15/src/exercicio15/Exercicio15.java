/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exercicio15;
import javax.swing.JOptionPane;
/**
 *
 * @author anaca
 */
public class Exercicio15 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
     double saldo = 1000.0;
     String menu = "Bem-vindo ao Caixa!\n"
             + "Escolha uma das opções:\n"
             + "1 - Saque\n"
             + "2 - Depósito\n"
             + "3 - Consultar saldo";
     
     int opcao = Integer.parseInt(JOptionPane.showInputDialog(menu));
     
     switch (opcao) {
         case 1: 
              double saque = Double.parseDouble(JOptionPane.showInputDialog("Digite o valor do saque:"));
        if (saque > 0 && saque <= saldo) {
            saldo -= saque;
            JOptionPane.showMessageDialog(null,"Saque realizado!\n"
                    + "Seu saldo atual: R$" + saldo);
        } else {
            JOptionPane.showMessageDialog(null,"Valor para saque inválido");
        }
        break;
        
             
         case 2:
             double deposito = Double.parseDouble(JOptionPane.showInputDialog("Digite o valor do depósito:"));
             if (deposito > 0) {
                 saldo += deposito;
                 JOptionPane.showMessageDialog(null,"Depósito realizado!\n"
                         + "Seu saldo atual: R$" + saldo);
             } else {
                 JOptionPane.showMessageDialog(null,"Valor para depósito inválido");
             }
             break;
             
         case 3:
             JOptionPane.showMessageDialog(null,"Seu saldo atual é:" + saldo);
             break;
       
         default:
             JOptionPane.showMessageDialog(null,"Opção inválida");
             break;
                 
    }
    
}
}