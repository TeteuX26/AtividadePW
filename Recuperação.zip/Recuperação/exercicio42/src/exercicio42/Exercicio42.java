/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exercicio42;
import java.util.Scanner;
/**
 *
 * @author anaca
 */
public class Exercicio42 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
      int num, positivos = 0;
        do {
            System.out.print("Digite um numero: ");
            num = scanner.nextInt();
            if (num >= 0) positivos++;
        } while (num >= 0);
        System.out.println("Total positivos: " + positivos);
    }
    
}
