/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exercicio48;

import java.util.Scanner;

/**
 *
 * @author anaca
 */
public class Exercicio48 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner scanner = new Scanner (System.in);
        char resposta;
        do {
          
            System.out.print("Nome do aluno: ");
            String aluno = scanner.nextLine();
            System.out.print("Nota 1: ");
            double n1 = scanner.nextDouble();
            System.out.print("Nota 2: ");
            double n2 = scanner.nextDouble();
            System.out.println("Média: " + ((n1 + n2) / 2));
            System.out.print("Deseja continuar? (s/n): ");
            resposta = scanner.next().charAt(0);
        } while (resposta == 's' || resposta == 'S');

    }
    
}
