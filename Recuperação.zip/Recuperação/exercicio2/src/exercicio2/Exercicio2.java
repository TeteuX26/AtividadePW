package exercicio2;
import javax.swing.JOptionPane;
/**
 *
 * @author anaca
 */
public class Exercicio2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
   
        int[][] matriz = new int[2][2];

        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < 2; j++) {
                String entrada = JOptionPane.showInputDialog("Digite um numero para a posição[" + i + "][" + j + "]:");
                matriz[i][j] = Integer.parseInt(entrada); 
            }
        }

        StringBuilder saida = new StringBuilder("Matriz 2x2:\n");
        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < 2; j++) {
                saida.append(matriz[i][j]).append("\t");  // Corrigido: adicionei o '\t' para formatação de tabulação
            }
            saida.append("\n");
        }

        JOptionPane.showMessageDialog(null, saida.toString());
    }
}





