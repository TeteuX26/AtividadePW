/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exercicio43;

import java.util.Scanner;

/**
 *
 * @author anaca
 */
public class Exercicio43 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner scanner = new Scanner (System.in);
        int opcao;
        do {
            System.out.println("1 - Opcaoo A\n2 - Opcao B\n3 - Opcao C\n0 - Sair");
            opcao = scanner.nextInt();
            System.out.println("Voce escolheu: " + opcao);
        } while (opcao != 0);
    }
    
}
