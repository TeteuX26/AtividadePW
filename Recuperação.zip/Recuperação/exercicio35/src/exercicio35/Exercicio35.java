/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exercicio35;

import javax.swing.JOptionPane;

/**
 *
 * @author anaca
 */
public class Exercicio35 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
     int idade, total = 0;
       int cont = 0;
        do {
            idade = Integer.parseInt(JOptionPane.showInputDialog("Digite a idade (-1 para sair):"));
            if (idade != -1) {
                total += idade;
                cont++;
            }
        } while (idade != -1);
        JOptionPane.showMessageDialog(null, "Média de idades: " + (cont > 0 ? (total / cont) : 0));
    }
    
}
