/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exercicio46;

import java.util.Scanner;

/**
 *
 * @author anaca
 */
public class Exercicio46 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int segredo = 7, palpite;
        do {
            System.out.print("Adivinhe o numero: ");
            palpite = scanner.nextInt();
        } while (palpite != segredo);
        System.out.println("Acertou!");
    }
    
}
