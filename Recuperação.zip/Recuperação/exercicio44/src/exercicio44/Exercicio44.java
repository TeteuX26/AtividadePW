/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exercicio44;

import java.util.Scanner;

/**
 *
 * @author anaca
 */
public class Exercicio44 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner scanner = new Scanner (System.in);
        String nome;
        do {
            System.out.print("Digite um nome (ou 'fim' para encerrar): ");
            nome = scanner.nextLine();
            if (!nome.equalsIgnoreCase("fim"))
                System.out.println("Nome: " + nome);
        } while (!nome.equalsIgnoreCase("fim"));

    }
    
}
