/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exercicio38;

import javax.swing.JOptionPane;

/**
 *
 * @author anaca
 */
public class Exercicio38 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int i = Integer.parseInt(JOptionPane.showInputDialog("Digite o número inicial da contagem regressiva:"));
        String regressiva = "";
        while (i >= 0) {
            regressiva += i + " ";
            i--;
        }
        JOptionPane.showMessageDialog(null, regressiva);

    }
    
}
