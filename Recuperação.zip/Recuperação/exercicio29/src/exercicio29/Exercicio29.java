/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exercicio29;
import java.util.Scanner;
/**
 *
 * @author anaca
 */
public class Exercicio29 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    Scanner scanner = new Scanner (System.in);
         System.out.print("Digite um numero: ");
        int numero = scanner.nextInt();

        int divisores = 0;

        for (int i = 1; i <= numero; i++) {
            if (numero % i == 0) {
                divisores++;
            }
        }

        if (divisores == 2) {
            System.out.println(numero + " eh primo.");
        } else {
            System.out.println(numero + " nao eh primo.");
        }

       scanner.close();    }
    
}
