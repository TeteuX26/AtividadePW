/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exercicio16;
import javax.swing.JOptionPane;
/**
 *
 * @author anaca
 */
public class Exercicio16 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       String produto = JOptionPane.showInputDialog("Digite o nome do produto:");
       
       switch (produto.toLowerCase()) {
           case "maçã":
           case "banana":
           case "laranja":
               JOptionPane.showMessageDialog(null, "A categoria do produto é: Frutas");
               break;
               
           case "cenoura":
           case "alface":
           case "batata":
               JOptionPane.showMessageDialog(null, "A categoria do produto é: Legumes");
               break;
               
           default:
               JOptionPane.showMessageDialog(null, "Categoria não encontrada");
               break;
       }
       
    }
    
}
