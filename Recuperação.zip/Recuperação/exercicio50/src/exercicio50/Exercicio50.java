/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exercicio50;

import java.util.Scanner;

/**
 *
 * @author anaca
 */
public class Exercicio50 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Scanner scanner = new Scanner (System.in);
        double saldo = 1000;
         int opcao;

        do {
            System.out.println("1 - Depositar\n2 - Sacar\n3 - Ver saldo\n0 - Sair");
            opcao = scanner.nextInt(); 

            switch (opcao) {
                case 1:
                    System.out.print("Valor: ");
                    saldo += scanner.nextDouble();
                    break;
                case 2:
                    System.out.print("Valor: ");
                    double saque = scanner.nextDouble();
                    if (saque <= saldo) saldo -= saque;
                    else System.out.println("Saldo insuficiente.");
                    break;
                case 3:
                    System.out.println("Saldo: " + saldo);
                    break;
                case 0:
                    System.out.println("Saindo...");
                    break;
                default:
                    System.out.println("Opção inválida.");
            }

        } while (opcao != 0);

        scanner.close();
    }
}