/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exercicio23;
/**
 *
 * @author anaca
 */
public class Exercicio23 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
     int contador = 0;
     
     for (int i = 1; i <= 50; i++) {
        if (i % 2 == 0) {
            contador++;
        }
     }
       System.out.println("Quantidade de numeros pares de 1 a 50: " + contador);
       
    }
    
}
