/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exercicio30;
import java.util.Scanner;
/**
 *
 * @author anaca
 */
public class Exercicio30 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      Scanner scanner = new Scanner (System.in);
        System.out.println("Quantos termos da sequencia de Fibonacci voce quer ver? ");
        int n = scanner.nextInt();

        int a = 0, b = 1;

        System.out.println("Sequencia de Fibonacci com " + n + " termo(s):");

        for (int i = 1; i <= n; i++) {
            System.out.print(a + " ");

            int proximo = a + b;
            a = b;
            b = proximo;
        }

        scanner.close();
    }
    
}
