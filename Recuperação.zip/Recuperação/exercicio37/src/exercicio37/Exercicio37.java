/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exercicio37;

import javax.swing.JOptionPane;

/**
 *
 * @author anaca
 */
public class Exercicio37 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
           double nota, somaNotas = 0;
       int cont = 0;
        do {
            nota = Double.parseDouble(JOptionPane.showInputDialog("Digite uma nota (0 a 10):"));
            if (nota >= 0 && nota <= 10) {
                somaNotas += nota;
                cont++;
            }
        } while (nota >= 0 && nota <= 10);
        JOptionPane.showMessageDialog(null, "Média: " + (cont > 0 ? (somaNotas / cont) : 0));

    }
    
}
