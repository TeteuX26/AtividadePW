/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exercicio31;

import javax.swing.JOptionPane;

/**
 *
 * @author anaca
 */
public class Exercicio31 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         int num, soma = 0;
        do {
            num = Integer.parseInt(JOptionPane.showInputDialog("Digite um número (0 para sair):"));
            soma += num;
        } while (num != 0);
        JOptionPane.showMessageDialog(null, "Soma: " + soma);
    }
    
}
