/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exercicio49;

import java.util.Scanner;

/**
 *
 * @author anaca
 */
public class Exercicio49 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner scanner = new Scanner (System.in);

        String login, senha;
        int tentativas = 0;

        do {
            System.out.print("Digite o login: ");
            login = scanner.nextLine();

            System.out.print("Digite a senha: ");
            senha = scanner.nextLine();

            tentativas++;

            if (login.equals("admin") && senha.equals("1234")) {
                System.out.println("Acesso autorizado.");
                break;
            } else {
                System.out.println("Login ou senha incorretos. Tentativa " + tentativas + " de 3");
            }

        } while (tentativas < 3);

        if (!(login.equals("admin") && senha.equals("1234"))) {
            System.out.println("Acesso negado. Número de tentativas excedido.");
        }

        scanner.close();
    }

    }
    

