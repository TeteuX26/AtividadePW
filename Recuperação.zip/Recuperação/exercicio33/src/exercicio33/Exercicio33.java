/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exercicio33;

import javax.swing.JOptionPane;

/**
 *
 * @author anaca
 */
public class Exercicio33 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       String senha;
        do {
            senha = JOptionPane.showInputDialog("Digite a senha:");
        } while (!senha.equals("1234"));
        JOptionPane.showMessageDialog(null, "Senha correta!");
    }
    
}
