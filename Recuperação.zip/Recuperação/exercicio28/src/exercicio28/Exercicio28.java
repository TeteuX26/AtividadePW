/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exercicio28;
import java.util.Scanner;
/**
 *
 * @author anaca
 */
public class Exercicio28 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Scanner scanner = new Scanner (System.in);
       
       System.out.println("Digite um numero para calcular o fatorial:");
       int num = scanner.nextInt();
       
       long fatorial = 1;
       
       for (int i = num; i >= 1; i--) {
           fatorial *= i;
       }
       System.out.println("Fatorial de " + num + " eh: " + fatorial);
        scanner.close();
     
    }
}
