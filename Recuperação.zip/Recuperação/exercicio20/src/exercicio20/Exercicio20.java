/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exercicio20;
import javax.swing.JOptionPane;
/**
 *
 * @author anaca
 */
public class Exercicio20 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String[] candidatos = {
            "1 - Matheus",
            "2 - Bruno",
            "3 - Estevam"
        };

        int[] votos = new int[3];

        String menu = "Eleição 2025\n\n";
        for (String candidato : candidatos) {
            menu += candidato + "\n";
        }
        menu += "\nDigite o número do candidato (1, 2 ou 3)\nDigite 0 para encerrar.";

        while (true) {
            String entrada = JOptionPane.showInputDialog(null, menu, "Votação", JOptionPane.QUESTION_MESSAGE);

            if (entrada == null) break;

            try {
                int voto = Integer.parseInt(entrada);

                if (voto == 0) {
                    break;
                } else if (voto >= 1 && voto <= 3) {
                    votos[voto - 1]++;
                    String nome = candidatos[voto - 1].split("-")[1].trim();
                    JOptionPane.showMessageDialog(null, "Voto registrado para " + nome);
                } else {
                    JOptionPane.showMessageDialog(null, "Número inválido.");
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Entrada inválida. Digite apenas números.");
            }
        }

        String resultado = "Resultado Final\n\n";
        int maiorVoto = 0;

        for (int i = 0; i < votos.length; i++) {
            String nome = candidatos[i].split("-")[1].trim();
            resultado += nome + ": " + votos[i] + " voto(s)\n";
            if (votos[i] > maiorVoto) {
                maiorVoto = votos[i];
            }
        }

        resultado += "\nVencedor(es):\n";
        for (int i = 0; i < votos.length; i++) {
            if (votos[i] == maiorVoto && maiorVoto > 0) {
                String nome = candidatos[i].split("-")[1].trim();
                resultado += "- " + nome + "\n";
            }
        }

        JOptionPane.showMessageDialog(null, resultado, "Resultado da Eleição", JOptionPane.INFORMATION_MESSAGE);
    }
}
