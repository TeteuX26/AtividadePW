/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exercicio19;
import javax.swing.JOptionPane;
/**
 *
 * @author anaca
 */
public class Exercicio19 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String[] nomes = new String[100];
        int clientes = 0;
        int opcao = 0;

        do {
            opcao = Integer.parseInt(JOptionPane.showInputDialog(
                    "Menu Clientes:\n"
                    + "1 - Adicionar clientes\n"
                    + "2 - Listar clientes\n"
                    + "3 - Editar clientes\n"
                    + "4 - Excluir clientes\n"
                    + "5 - Sair"));

            switch (opcao) {
                case 1:
                    if (clientes < nomes.length) {
                        String nome = JOptionPane.showInputDialog("Digite o nome do cliente:");
                        nomes[clientes] = nome;
                        clientes++;
                        JOptionPane.showMessageDialog(null, "Cliente adicionado com sucesso!");
                    } else {
                        JOptionPane.showMessageDialog(null, "Limite de clientes atingido");
                    }
                    break;

                case 2:
                    if (clientes == 0) {
                        JOptionPane.showMessageDialog(null, "Nenhum cliente cadastrado");
                    } else {
                        String lista = "Lista de clientes:\n";
                        for (int i = 0; i < clientes; i++) {
                            lista += (i + 1) + " - " + nomes[i] + "\n";
                        }
                        JOptionPane.showMessageDialog(null, lista);
                    }
                    break;

                case 3:
                    if (clientes == 0) {
                        JOptionPane.showMessageDialog(null, "Nenhum cliente para editar");
                    } else {
                        int num = Integer.parseInt(JOptionPane.showInputDialog("Digite o número do cliente para editar:"));
                        if (num >= 1 && num <= clientes) {
                            String novoNome = JOptionPane.showInputDialog("Digite o novo nome:");
                            nomes[num - 1] = novoNome;
                            JOptionPane.showMessageDialog(null, "Nome atualizado!");
                        } else {
                            JOptionPane.showMessageDialog(null, "Número inválido");
                        }
                    }
                    break;

                case 4:
                    if (clientes == 0) {
                        JOptionPane.showMessageDialog(null, "Nenhum cliente para excluir");
                    } else {
                        int excluir = Integer.parseInt(JOptionPane.showInputDialog("Digite o número do cliente para exclusão:"));
                        if (excluir >= 1 && excluir <= clientes) {
                            for (int i = excluir - 1; i < clientes - 1; i++) {
                                nomes[i] = nomes[i + 1];
                            }
                            clientes--;
                            JOptionPane.showMessageDialog(null, "Cliente excluído!");
                        } else {
                            JOptionPane.showMessageDialog(null, "Número inválido");
                        }
                    }
                    break;

                case 5:
                    JOptionPane.showMessageDialog(null, "Saindo do sistema...");
                    break;

                default:
                    JOptionPane.showMessageDialog(null, "Opção inválida");
                    break;
            }

        } while (opcao != 5);
    }
}

