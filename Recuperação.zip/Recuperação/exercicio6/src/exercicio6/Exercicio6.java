/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exercicio6;
import java.util.Scanner;
/**
 *
 * @author Admin
 */
public class Exercicio6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Scanner scanner = new Scanner(System.in);
       int[][] matriz = new int[3][3];
       int contador = 0;
       
       for(int i = 0; i < 3; i++) {
           for(int j = 0; i < 3; i++) {
               System.out.println("Digite o numero para a posicao" + i + j + ":");
               matriz[i][j] = scanner.nextInt();
               
               if(matriz[i][j] > 10) {
                   contador++;
               }
           }
       }
       System.out.println("OS numeros que sao maiores que 10:" + contador);
                 scanner.close();
    }
    
}
