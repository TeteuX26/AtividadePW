/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exercicio7;
import java.util.Scanner;
/**
 *
 * @author Admin
 */
public class Exercicio7 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Scanner scanner = new Scanner(System.in);
       int [] vetor1 = new int[5];
       int [] vetor2 = new int[5];
       int [] vetor3 = new int[5];
       
       System.out.println("Digite os 5 valores do primeiro vetor:");
       for (int i = 0; i < 5; i++) {
         System.out.println("Vetor1["+ i +"]:");
            vetor1[i] = scanner.nextInt();
            
   
       }
     System.out.println("Digite os 5 valores do segundo vetor:");
         for (int i = 0; i < 5; i++) {
            System.out.println("Vetor2["+ i +"]:");
            vetor2[i] = scanner.nextInt();
         }
         for (int i = 0; i < 5; i++) {
            vetor3[i] = vetor1[i] + vetor2[i];
         }
         
       System.out.println("Valor resultante da soma:");
       for (int i = 0; i < 5; i++) {
           System.out.println("Vetor3["+ i +"]=" + vetor3[i]);
       }
       scanner.close();
    }
}
    
