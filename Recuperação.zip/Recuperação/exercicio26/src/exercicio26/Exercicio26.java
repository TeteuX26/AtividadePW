/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exercicio26;
import java.util.Scanner;
/**
 *
 * @author anaca
 */
public class Exercicio26 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("Digite um numero para saber a tabuada: ");
        int num = scanner.nextInt();
        
        System.out.println("Tabuada do " + num + ":");
        for (int i = 0; i <= 10; i++) {
            int resultado = num * i;
            System.out.println(num + " X " + i + " = " + resultado);
        }
        scanner.close();
    }
    
}
