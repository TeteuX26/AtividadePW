/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exercicio5;
import java.util.Scanner;
/**
 *
 * @author Admin
 */
public class Exercicio5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Scanner scanner = new Scanner(System.in);
        int soma = 0;
        int[] notas = new int[10];
        
        for (int i = 0; i < 10; i++) {
            System.out.println("Digite a nota" + i  + ":");
            notas[i] = scanner.nextInt();   
            soma += notas[i];
        }
      
       int media = soma / 10;
       
       System.out.println("A media das notas eh:" + media);
       
       scanner.close();
       
    
    }
    
}
