/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exercicio11;
import javax.swing.JOptionPane;
/**
 *
 * @author anaca
 */
public class Exercicio11 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      int escola = Integer.parseInt(JOptionPane.showInputDialog("Digite a numeração da sua escola:\n"
               + "1 - Etec Zona Leste\n"
               + "2 - Etec São Miguel\n"
               + "3 - Etec Itaquera"));
       
       switch (escola) {
           case 1:
               JOptionPane.showMessageDialog(null,"Você está na Etec Zona Leste");
           break;
           
           case 2:
               JOptionPane.showMessageDialog(null,"Você está na Etec São Miguel");
           break;
           
           case 3: 
               JOptionPane.showMessageDialog(null,"Você está na Etec Itaquera");
           break;
           
           default:
               JOptionPane.showMessageDialog(null,"Numeração inválida");
            break;
               
       }
       
      
       
    }
    
}
