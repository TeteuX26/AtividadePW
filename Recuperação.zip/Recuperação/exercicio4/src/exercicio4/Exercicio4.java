/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exercicio4;
import java.util.Scanner;
/**
 *
 * @author anaca
 */
public class Exercicio4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
     Scanner scanner = new Scanner (System.in);
     int [][] matriz = new int [3][3];
     
     System.out.println("Digite os elementos da matriz:");
     for(int i = 0; i < 3; i++) {
         for(int j = 0; j < 3; j++) {
             System.out.println("Elemento" + i + j + ":");
             matriz [i][j] = scanner.nextInt();
     }
    }
     System.out.println("Elementos da diagonal principal:");
     for(int i = 0; i < 3; i++){
     System.out.println(matriz[i][i]);
  }
      scanner.close();
 }
}