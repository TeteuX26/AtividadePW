/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exercicio12;
import javax.swing.JOptionPane;
/**
 *
 * @author anaca
 */
public class Exercicio12 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
     int dias = Integer.parseInt(JOptionPane.showInputDialog("Digite um número de 1 a 7:"));
     
     switch (dias) {
         case 1:
             JOptionPane.showMessageDialog(null,"Domingo");
             break;
         case 2: 
             JOptionPane.showMessageDialog(null,"Segunda-feira");
             break;
         case 3:
             JOptionPane.showMessageDialog(null, "Terça-feira");
             break;
         case 4: 
             JOptionPane.showMessageDialog(null,"Quarta-feira");
             break;
         case 5:
             JOptionPane.showMessageDialog(null,"Quinta-feira");
             break;
         case 6:
             JOptionPane.showMessageDialog(null,"Sexta-feira");
             break;
         case 7: 
             JOptionPane.showMessageDialog(null,"Sábado");
             break;
             
         default:
             JOptionPane.showMessageDialog(null,"Número inválido");
             break;
             
     }
    }
    
}
