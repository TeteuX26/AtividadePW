const use = {
name: "Matheus"
}

console.log(User.name);