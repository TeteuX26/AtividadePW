<?php

include_once(__DIR__."/../model/Aluno.php");
include_once(__DIR__."/../model/Aluno.php");


$alunoNome = $_GET['nomealuno'];
$cursoNome = $_GET['nomecurso'];

$Matheus = new Aluno ($alunoNome, 222);
$cursoDS = new Curso ($alunoNome);

$matricula = new Matricula ($Matheus, $cursoDS);

var_dump ($Matheus);