<?php

$alunoNome = $_GET['alnome'];

echo $alunoNome;