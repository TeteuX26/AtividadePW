<?php

    class Aluno{

        private $rm;

        public function getRm(): String{
            return $this->rm;
        }
    }