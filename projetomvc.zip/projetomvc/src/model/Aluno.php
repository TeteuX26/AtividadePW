<?php

include_once "Pessoa.php";
    class Aluno extends Pessoa{
        private $rm;
        public function __construct($nome, $numerorm){
            parent::__construct($nome);
            $this->rm = $numerorm;
        }
        public function getRm(): String{
            return $this->rm;
        }
    }