<?php
class Pessoa{
    public $nome;

    function __construct($nome){
        $this->nome = $nome;
    }

    public  function falar(){
        echo "Esta falando...";
    }
}