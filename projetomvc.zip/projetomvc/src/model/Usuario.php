<?php
class Usuario{
    private $nomelogin;

    public function getNomeDeLogin(): String {
        return $this->nomelogin;
    }
}