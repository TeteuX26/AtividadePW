<?php

class Curso{
    private $nome;

    public function getNome() : String {
        return $this->nome;
    }
}